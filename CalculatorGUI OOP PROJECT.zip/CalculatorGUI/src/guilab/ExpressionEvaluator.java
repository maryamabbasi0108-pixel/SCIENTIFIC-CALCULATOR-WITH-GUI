package guilab;

import java.util.*;
import java.util.regex.*;

public class ExpressionEvaluator {

	private static final Map<String, Integer> OPERATORS = new HashMap<>();
	static {
	    OPERATORS.put("+", 1);
	    OPERATORS.put("-", 1);
	    OPERATORS.put("*", 2);
	    OPERATORS.put("/", 2);
	    OPERATORS.put("^", 3);
	}

    private static final Set<String> FUNCTIONS = new HashSet<>(Arrays.asList(
    	    "sin", "cos", "tan", "log", "ln", "sqrt", "fact"
    	));

    public double evaluate(String expression) throws Exception {
        List<String> tokens = tokenize(expression);
        List<String> postfix = infixToPostfix(tokens);
        return evaluatePostfix(postfix);
    }

    private List<String> tokenize(String expr) {
        List<String> tokens = new ArrayList<>();
        Matcher m = Pattern.compile(
            "\\d*\\.?\\d+|[a-zA-Z]+|\\S"
        ).matcher(expr);
        while (m.find()) {
            tokens.add(m.group());
        }
        return tokens;
    }

    private List<String> infixToPostfix(List<String> tokens) throws Exception {
        List<String> output = new ArrayList<>();
        Stack<String> stack = new Stack<>();

        for (String token : tokens) {
            if (isNumber(token) || isConstant(token)) {
                output.add(token);
            } else if (FUNCTIONS.contains(token)) {
                stack.push(token);
            } else if (token.equals(",")) {
                while (!stack.isEmpty() && !stack.peek().equals("(")) {
                    output.add(stack.pop());
                }
                if (stack.isEmpty()) throw new Exception("Mismatched parentheses or misplaced comma");
            } else if (OPERATORS.containsKey(token)) {
                while (!stack.isEmpty() && OPERATORS.containsKey(stack.peek()) &&
                        ((isLeftAssociative(token) && OPERATORS.get(token) <= OPERATORS.get(stack.peek())) ||
                         (!isLeftAssociative(token) && OPERATORS.get(token) < OPERATORS.get(stack.peek())))) {
                    output.add(stack.pop());
                }
                stack.push(token);
            } else if (token.equals("(")) {
                stack.push(token);
            } else if (token.equals(")")) {
                while (!stack.isEmpty() && !stack.peek().equals("(")) {
                    output.add(stack.pop());
                }
                if (stack.isEmpty()) throw new Exception("Mismatched parentheses");
                stack.pop(); // pop '('
                if (!stack.isEmpty() && FUNCTIONS.contains(stack.peek())) {
                    output.add(stack.pop());
                }
            } else {
                throw new Exception("Unknown token: " + token);
            }
        }
        while (!stack.isEmpty()) {
            if (stack.peek().equals("(") || stack.peek().equals(")")) {
                throw new Exception("Mismatched parentheses");
            }
            output.add(stack.pop());
        }
        return output;
    }

    private double evaluatePostfix(List<String> postfix) throws Exception {
        Stack<Double> stack = new Stack<>();

        for (String token : postfix) {
            if (isNumber(token)) {
                stack.push(Double.parseDouble(token));
            } else if (isConstant(token)) {
                stack.push(getConstantValue(token));
            } else if (OPERATORS.containsKey(token)) {
                if (stack.size() < 2) throw new Exception("Insufficient operands");
                double b = stack.pop();
                double a = stack.pop();
                stack.push(applyOperator(token, a, b));
            } else if (FUNCTIONS.contains(token)) {
                if (stack.isEmpty()) throw new Exception("Insufficient operands for function");
                double a = stack.pop();
                stack.push(applyFunction(token, a));
            } else {
                throw new Exception("Unknown token in postfix: " + token);
            }
        }

        if (stack.size() != 1) throw new Exception("Invalid expression");
        return stack.pop();
    }

    private boolean isNumber(String s) {
        return s.matches("\\d*\\.?\\d+");
    }

    private boolean isConstant(String s) {
        return s.equals("π") || s.equals("e");
    }

    private double getConstantValue(String s) {
        switch (s) {
            case "π": return Math.PI;
            case "e": return Math.E;
            default: return 0;
        }
    }

    private boolean isLeftAssociative(String op) {
        return !op.equals("^");
    }

    private double applyOperator(String op, double a, double b) {
        switch (op) {
            case "+": return a + b;
            case "-": return a - b;
            case "*": return a * b;
            case "/": return a / b;
            case "^": return Math.pow(a, b);
            default: return 0;
        }
    }

    private double applyFunction(String func, double a) throws Exception {
        switch (func) {
            case "sin": return Math.sin(a);
            case "cos": return Math.cos(a);
            case "tan": return Math.tan(a);
            case "log": return Math.log10(a);
            case "ln": return Math.log(a);
            case "sqrt": return Math.sqrt(a);
            case "fact":
                if (a < 0 || a != Math.floor(a)) throw new Exception("Invalid input for factorial");
                return factorial((int)a);
            default:
                throw new Exception("Unknown function: " + func);
        }
    }

    private double factorial(int n) {
        double fact = 1;
        for (int i = 2; i <= n; i++) fact *= i;
        return fact;
    }
}
