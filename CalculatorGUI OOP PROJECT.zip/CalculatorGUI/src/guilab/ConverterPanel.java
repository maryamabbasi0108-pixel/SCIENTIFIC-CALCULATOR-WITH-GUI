package guilab;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class ConverterPanel extends JPanel implements ActionListener {
	private static final long serialVersionUID = 1L;
    private JComboBox<String> fromBox, toBox;
    private JTextField inputField, outputField;
    private JButton convertBtn;
    private String selectedCategory = null;
    private CalculatorLogic logic = new CalculatorLogic();

    private JPanel inputPanel, valuePanel, conversionPanel;

    public ConverterPanel() {
        setLayout(new BorderLayout());
        setBackground(Color.BLACK);

        // === CATEGORY BUTTONS PANEL ===
     // === CATEGORY BUTTONS PANEL ===
        JPanel categoryPanel = new JPanel(new GridLayout(5, 2, 5, 5));
        categoryPanel.setBackground(Color.BLACK);
        categoryPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 10, 20));

        String[] categories = {
            "Length", "Mass", "Area",
            "Time", "Discount", "Volume",
            "Numeral system", "Speed", "Temperature",
            "Data"
        };


        for (String cat : categories) {
            JButton btn = new JButton(cat);
            btn.setPreferredSize(new Dimension(160, 50)); // Thinner button
            btn.setFont(new Font("Arial", Font.PLAIN, 13)); // Smaller readable text
            btn.setHorizontalAlignment(SwingConstants.CENTER);
            btn.setVerticalAlignment(SwingConstants.CENTER);
            btn.setToolTipText(cat); // Show full name on hover
            btn.setBackground(new Color(60, 60, 60));
            btn.setForeground(Color.WHITE);
            btn.setFocusPainted(false);
            btn.addActionListener(e -> {
                selectedCategory = cat;
                updateUnits(cat);
                showConversionFields(true);
            });
            categoryPanel.add(btn);
        }

        // === CONVERSION FIELDS ===
        fromBox = new JComboBox<>();
        fromBox.setBackground(new Color(40, 40, 40));
        fromBox.setForeground(Color.WHITE);

        toBox = new JComboBox<>();
        toBox.setBackground(new Color(40, 40, 40));
        toBox.setForeground(Color.WHITE);

        inputField = new JTextField();
        inputField.setBackground(new Color(30, 30, 30));
        inputField.setForeground(Color.WHITE);
        inputField.setFont(new Font("Arial", Font.PLAIN, 14)); // ↓ Font size
        inputField.setPreferredSize(new Dimension(100, 25));   // ↓ Height

        outputField = new JTextField();
        outputField.setBackground(new Color(30, 30, 30));
        outputField.setForeground(Color.WHITE);
        outputField.setFont(new Font("Arial", Font.BOLD, 14)); // ↓ Font size
        outputField.setPreferredSize(new Dimension(100, 25));  // ↓ Height
        outputField.setEditable(false);

        convertBtn = new JButton("Convert");
        convertBtn.setBackground(new Color(255, 140, 0));
        convertBtn.setForeground(Color.BLACK);
        convertBtn.setFont(new Font("Arial", Font.BOLD, 16));
        convertBtn.addActionListener(this);

        inputPanel = new JPanel(new GridLayout(2, 2, 10, 10));
        inputPanel.setBackground(Color.BLACK);
        inputPanel.add(createLabel("From:"));
        inputPanel.add(fromBox);
        inputPanel.add(createLabel("To:"));
        inputPanel.add(toBox);

        valuePanel = new JPanel(new GridLayout(2, 2, 10, 10));
        valuePanel.setBackground(Color.BLACK);
        valuePanel.add(createLabel("Input:"));
        valuePanel.add(inputField);
        valuePanel.add(createLabel("Output:"));
        valuePanel.add(outputField);

        conversionPanel = new JPanel(new BorderLayout(10, 10));
        conversionPanel.setBackground(Color.BLACK);
        conversionPanel.setBorder(BorderFactory.createEmptyBorder(10, 20, 20, 20));
        conversionPanel.add(inputPanel, BorderLayout.NORTH);
        conversionPanel.add(valuePanel, BorderLayout.CENTER);
        conversionPanel.add(convertBtn, BorderLayout.SOUTH);
        showConversionFields(false);

        add(categoryPanel, BorderLayout.NORTH);
        add(conversionPanel, BorderLayout.CENTER);
    }

    private JLabel createLabel(String text) {
        JLabel label = new JLabel(text);
        label.setForeground(Color.WHITE);
        return label;
    }

    private void showConversionFields(boolean show) {
        conversionPanel.setVisible(show);
        revalidate();
        repaint();
    }

    private void updateUnits(String category) {
        fromBox.removeAllItems();
        toBox.removeAllItems();

        String[] units;
        switch (category) {
            case "Length":
                units = new String[]{"Kilometer", "Meter", "Centimeter", "Millimeter", "Mile", "Yard", "Foot", "Inch"}; break;
            case "Mass":
                units = new String[]{"Kilogram", "Gram", "Milligram", "Pound", "Ounce"}; break;
            case "Area":
                units = new String[]{"Square meter", "Square kilometer", "Square mile", "Square yard", "Square foot", "Square inch", "Hectare", "Acre"}; break;
            case "Time":
                units = new String[]{"Second", "Minute", "Hour", "Day", "Week", "Month", "Year"}; break;
            case "Discount":
                units = new String[]{"Percent", "Decimal"}; break;
            case "Volume":
                units = new String[]{"Liter", "Milliliter", "Cubic meter", "Cubic centimeter", "Gallon", "Pint"}; break;
            case "Numeral system":
                units = new String[]{"Binary", "Octal", "Decimal", "Hexadecimal"}; break;
            case "Speed":
                units = new String[]{"m/s", "km/h", "mph", "ft/s"}; break;
            case "Temperature":
                units = new String[]{"Celsius", "Fahrenheit", "Kelvin"}; break;
            case "Data":
                units = new String[]{"Bit", "Byte", "Kilobyte", "Megabyte", "Gigabyte", "Terabyte"}; 
                break;
            default:
                units = new String[]{};
        }

        for (String u : units) {
            fromBox.addItem(u);
            toBox.addItem(u);
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String inputText = inputField.getText().trim();
        String from = (String) fromBox.getSelectedItem();
        String to = (String) toBox.getSelectedItem();

        if (inputText.isEmpty() || selectedCategory == null || from == null || to == null) {
            outputField.setText("Invalid input");
            return;
        }

        try {
            if (selectedCategory.equals("Numeral system")) {
                String result = logic.convertNumeralSystem(inputText, from, to);
                outputField.setText(result);
                outputField.setCaretPosition(0);
            } else {
                double inputValue = Double.parseDouble(inputText);
                switch (selectedCategory) {
                    case "Length": inputValue = logic.convertLength(inputValue, from, to); break;
                    case "Mass": inputValue = logic.convertMass(inputValue, from, to); break;
                    case "Area": inputValue = logic.convertArea(inputValue, from, to); break;
                    case "Time": inputValue = logic.convertTime(inputValue, from, to); break;
                    case "Discount": inputValue = logic.convertDiscount(inputValue, from, to); break;
                    case "Volume": inputValue = logic.convertVolume(inputValue, from, to); break;
                    case "Speed": inputValue = logic.convertSpeed(inputValue, from, to); break;
                    case "Temperature": inputValue = logic.convertTemperature(inputValue, from, to); break;
                }
                outputField.setText(String.valueOf(inputValue));
                outputField.setCaretPosition(0);
            }
        } catch (NumberFormatException ex) {
            outputField.setText("Invalid number");
        } catch (Exception ex) {
            outputField.setText("Error");
        }
    }
}
