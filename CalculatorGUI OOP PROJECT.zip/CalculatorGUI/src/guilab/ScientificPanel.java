package guilab;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class ScientificPanel extends JPanel implements ActionListener {
	private static final long serialVersionUID = 1L;
    private JTextField display;
    private String currentInput = "";
    private JPanel buttonsPanel;
    private Runnable basicModeToggleListener;

    public ScientificPanel() {
        setLayout(new BorderLayout());
        setBackground(Color.BLACK);

        display = new JTextField("0");
        display.setFont(new Font("Consolas", Font.BOLD, 36));
        display.setHorizontalAlignment(JTextField.RIGHT);
        display.setEditable(false);
        display.setBackground(Color.BLACK);
        display.setForeground(Color.WHITE);
        display.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        add(display, BorderLayout.NORTH);

        buildButtons();
    }

    private void buildButtons() {
        buttonsPanel = new JPanel(new GridLayout(8, 4, 8, 8));
        buttonsPanel.setBackground(Color.BLACK);
        buttonsPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        String[] buttons = {
        	    "AC", "←", "(", ")",
        	    "sin", "cos", "tan", "^",
        	    "log", "ln", "√", "x²",  
        	    "π", "e", "n!", "/",
        	    "7", "8", "9", "*",
        	    "4", "5", "6", "-",
        	    "1", "2", "3", "+",
        	    "⚙", "0", ".", "="
        	};

        for (String text : buttons) {
            JButton btn = new JButton(text);
            btn.setFont(new Font("Arial", Font.BOLD, 20));
            btn.setBackground(new Color(40, 40, 40));
            btn.setForeground(Color.WHITE);
            btn.setFocusPainted(false);
            btn.addActionListener(this);

            if ("AC←()".contains(text)) btn.setForeground(new Color(255, 140, 0));
            if ("=+".contains(text)) btn.setBackground(new Color(255, 140, 0));
            if ("/*^-".contains(text)) btn.setForeground(new Color(255, 140, 0));

            buttonsPanel.add(btn);
        }

        add(buttonsPanel, BorderLayout.CENTER);
    }

    public void setBasicModeToggleListener(Runnable listener) {
        this.basicModeToggleListener = listener;
    }

    private void toggleBasicMode() {
        if (basicModeToggleListener != null) basicModeToggleListener.run();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String cmd = e.getActionCommand();

        try {
            switch (cmd) {
                case "AC":
                    currentInput = "";
                    display.setText("0");
                    break;

                case "←":
                    if (!currentInput.isEmpty()) {
                        currentInput = currentInput.substring(0, currentInput.length() - 1);
                        display.setText(currentInput.isEmpty() ? "0" : currentInput);
                    }
                    break;

                case "π":
                case "e":
                    currentInput += cmd;
                    display.setText(currentInput);
                    display.setCaretPosition(0);
                    break;

                case "x²":
                    if (!currentInput.isEmpty()) {
                        double val = Double.parseDouble(currentInput);
                        val = val * val;

                        if (val == (long) val) {
                            currentInput = String.valueOf((long) val);
                        } else {
                            currentInput = String.valueOf(val);
                        }

                        display.setText(currentInput);
                        display.setCaretPosition(0);
                    }
                    break;

                case "n!":
                    if (!currentInput.isEmpty()) {
                        currentInput += "n!"; // We'll replace this later before evaluation
                        display.setText(currentInput);
                        display.setCaretPosition(0);
                    }
                    break;

                case "sin":
                case "cos":
                case "tan":
                case "log":
                case "ln":
                    currentInput += cmd + "(";
                    display.setText(currentInput);
                    display.setCaretPosition(0);
                    break;

                case "√":
                    currentInput += "sqrt(";
                    display.setText(currentInput);
                    display.setCaretPosition(0);
                    break;


                case "^":
                case "+":
                case "-":
                case "*":
                case "/":
                case "(":
                case ")":
                case ".":
                case "0": case "1": case "2": case "3": case "4":
                case "5": case "6": case "7": case "8": case "9":
                    currentInput += cmd;
                    display.setText(currentInput);
                    display.setCaretPosition(0);
                    break;

                case "=":
                    try {
                        String expr = currentInput;
                        // Replace special tokens for evaluator
                        expr = expr.replace("π", String.valueOf(Math.PI))
                                   .replace("e", String.valueOf(Math.E))
                                   .replace("n!", "fact");

                        ExpressionEvaluator evaluator = new ExpressionEvaluator();
                        double result = evaluator.evaluate(expr);

                        // Remove .0 if integer
                        if (result == (long) result) {
                            display.setText(String.valueOf((long) result));
                            currentInput = String.valueOf((long) result);
                        } else {
                            display.setText(String.valueOf(result));
                            currentInput = String.valueOf(result);
                        }

                        display.setCaretPosition(0);
                    } catch (Exception ex) {
                        display.setText("Error");
                        currentInput = "";
                    }
                    break;


                case "⚙":
                    toggleBasicMode();
                    break;
            }
        } catch (Exception ex) {
            display.setText("Error");
            currentInput = "";
        }
    }
}
