package guilab;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.List;
import java.util.ArrayList;
import java.util.Stack;

public class BasicPanel extends JPanel implements ActionListener {
	private static final long serialVersionUID = 1L;
    private JTextField display;
    private String currentInput = "";
    private final CalculatorLogic logic = new CalculatorLogic();
    private JPanel buttonsPanel;

    private boolean scientificMode = false;
    private Runnable scientificModeToggleListener;

    public BasicPanel() {
        setLayout(new BorderLayout());
        setBackground(Color.BLACK);

        display = new JTextField("0");
        display.setFont(new Font("Consolas", Font.BOLD, 36));
        display.setHorizontalAlignment(JTextField.RIGHT);
        display.setEditable(false);
        display.setBackground(Color.BLACK);
        display.setForeground(Color.WHITE);
        display.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        add(display, BorderLayout.NORTH);

        buildButtons();
    }

    private void buildButtons() {
        buttonsPanel = new JPanel(new GridLayout(5, 4, 8, 8));
        buttonsPanel.setBackground(Color.BLACK);
        buttonsPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        String[] buttons = {
                "AC", "←", "%", "/",
                "7", "8", "9", "x",
                "4", "5", "6", "+",
                "1", "2", "3", "-",
                "⚛", "0", ".", "="
        };

        for (String text : buttons) {
            JButton btn = new JButton(text);
            btn.setFont(new Font("Arial", Font.BOLD, 22));
            btn.setBackground(new Color(40, 40, 40));
            btn.setForeground(Color.WHITE);
            btn.setFocusPainted(false);
            btn.addActionListener(this);

            if (text.equals("=")) btn.setBackground(new Color(255, 140, 0));
            if ("AC←%/x+-".contains(text)) btn.setForeground(new Color(255, 140, 0));

            buttonsPanel.add(btn);
        }

        add(buttonsPanel, BorderLayout.CENTER);
    }

    public void setScientificModeToggleListener(Runnable listener) {
        this.scientificModeToggleListener = listener;
    }

    public boolean isScientificMode() {
        return scientificMode;
    }

    private void toggleScientificMode() {
        scientificMode = true;
        if (scientificModeToggleListener != null) scientificModeToggleListener.run();
    }
    
    private boolean endsWithOperator(String input) {
        return input.endsWith("+") || input.endsWith("-") || input.endsWith("x") || input.endsWith("/");
    }
    
    private String formatDouble(double value) {
        if (value == (long) value) {
            return String.format("%d", (long) value);
        } else {
            // Limit decimal places, e.g., 10, and remove trailing zeros
            return String.format("%.10f", value).replaceAll("0+$", "").replaceAll("\\.$", "");
        }
    }
    
    private double evaluateExpression(String expression) {
        List<String> postfix = infixToPostfix(expression);
        return evaluatePostfix(postfix);
    }

    private List<String> infixToPostfix(String expression) {
        List<String> output = new ArrayList<>();
        Stack<String> operators = new Stack<>();
        StringBuilder number = new StringBuilder();

        for (int i = 0; i < expression.length(); i++) {
            char ch = expression.charAt(i);

            if (Character.isDigit(ch) || ch == '.') {
                number.append(ch);
            } else {
                // If we collected a number, add it to output
                if (number.length() > 0) {
                    output.add(number.toString());
                    number.setLength(0);
                }

                if (ch == '(') {
                    operators.push("(");
                } else if (ch == ')') {
                    while (!operators.isEmpty() && !operators.peek().equals("(")) {
                        output.add(operators.pop());
                    }
                    if (!operators.isEmpty()) operators.pop(); // remove '('
                } else if (isOperator(ch)) {
                    String op = String.valueOf(ch);

                    // Detect unary minus
                    if (ch == '-') {
                        if (i == 0 || (i > 0 && (isOperator(expression.charAt(i - 1)) || expression.charAt(i - 1) == '('))) {
                            op = "u-"; // unary minus
                        }
                    }

                    while (!operators.isEmpty() && precedence(operators.peek()) >= precedence(op)) {
                        output.add(operators.pop());
                    }
                    operators.push(op);
                }
            }
        }

        // Add last number if any
        if (number.length() > 0) {
            output.add(number.toString());
        }

        while (!operators.isEmpty()) {
            output.add(operators.pop());
        }

        return output;
    }

    private double evaluatePostfix(List<String> postfix) {
        Stack<Double> stack = new Stack<>();

        for (String token : postfix) {
            if (isNumber(token)) {
                stack.push(Double.parseDouble(token));
            } else if (token.equals("u-")) {
                double val = stack.pop();
                stack.push(-val);
            } else {
                double b = stack.pop();
                double a = stack.pop();

                switch (token) {
                    case "+":
                        stack.push(a + b);
                        break;
                    case "-":
                        stack.push(a - b);
                        break;
                    case "*":
                        stack.push(a * b);
                        break;
                    case "/":
                        stack.push(a / b);
                        break;
                }
            }
        }

        return stack.pop();
    }


    private boolean isOperator(char ch) {
        return ch == '+' || ch == '-' || ch == '*' || ch == '/';
    }

    private int precedence(String op) {
        switch (op) {
            case "u-": return 3;  // unary minus highest precedence
            case "*": case "/": return 2;
            case "+": case "-": return 1;
        }
        return 0;
    }

    private boolean isNumber(String s) {
        try {
            Double.parseDouble(s);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        String cmd = e.getActionCommand();

        try {
            switch (cmd) {
                case "AC":
                    currentInput = "";
                    display.setText("0");
                    break;

                case "←":
                    if (!currentInput.isEmpty()) {
                        currentInput = currentInput.substring(0, currentInput.length() - 1);
                        display.setText(currentInput.isEmpty() ? "0" : currentInput);
                    }
                    break;

                case "+":
                case "x":
                case "/":
                    if (!currentInput.isEmpty() && !endsWithOperator(currentInput)) {
                        currentInput += cmd;
                        display.setText(currentInput);
                        display.setCaretPosition(0);
                    }
                    break;

                case "-":
                    if (currentInput.isEmpty()) {
                        // Allow unary minus as first character
                        currentInput += "-";
                        display.setText(currentInput);
                    } else if (!endsWithOperator(currentInput)) {
                        // Normal subtraction operator append
                        currentInput += "-";
                        display.setText(currentInput);
                        display.setCaretPosition(0);
                    }
                    break;

                case "%":
                    if (!currentInput.isEmpty()) {
                        double result = logic.percent(Double.parseDouble(currentInput));
                        display.setText(String.valueOf(result));
                        currentInput = String.valueOf(result);
                        display.setCaretPosition(0);
                    }
                    break;

                case "⚛":
                    toggleScientificMode();
                    break;

                case "=":
                    try {
                        String expr = currentInput.replace("x", "*");
                        double result = evaluateExpression(expr);

                        // Use your formatDouble method for formatting output
                        String formattedResult = formatDouble(result);

                        display.setText(formattedResult);
                        currentInput = formattedResult;
                        display.setCaretPosition(0);
                    } catch (Exception ex) {
                        display.setText("Error");
                        currentInput = "";
                    }
                    break;

                default:
                    if (cmd.matches("[0-9.]")) {
                        currentInput += cmd;
                        display.setText(currentInput);
                        display.setCaretPosition(0);
                    }
            }
        } catch (Exception ex) {
            display.setText("Error");
            currentInput = "";
        }
    }
}
