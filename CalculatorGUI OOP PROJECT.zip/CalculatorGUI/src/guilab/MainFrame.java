package guilab;

import javax.swing.*;
import java.awt.*;

public class MainFrame extends JFrame {
    private static final long serialVersionUID = 1L;

    private JTabbedPane tabbedPane;
    private JPanel calculatorPanel; // ✅ move this above where it's used
    private BasicPanel basicPanel;
    private ScientificPanel scientificPanel;
    private ConverterPanel converterPanel;

    public MainFrame() {
        setTitle("MIUI Calculator");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(340, 570);
        setLocationRelativeTo(null);

        tabbedPane = new JTabbedPane();
        tabbedPane.setBackground(Color.BLACK);
        tabbedPane.setForeground(Color.WHITE);

        basicPanel = new BasicPanel();
        scientificPanel = new ScientificPanel();
        converterPanel = new ConverterPanel();

        // ✅ Use calculatorPanel after it is declared
        calculatorPanel = new JPanel(new CardLayout());
        calculatorPanel.add(basicPanel, "Basic");
        calculatorPanel.add(scientificPanel, "Scientific");

        basicPanel.setScientificModeToggleListener(() -> {
            CardLayout cl = (CardLayout) calculatorPanel.getLayout();
            cl.show(calculatorPanel, "Scientific");
        });

        scientificPanel.setBasicModeToggleListener(() -> {
            CardLayout cl = (CardLayout) calculatorPanel.getLayout();
            cl.show(calculatorPanel, "Basic");
        });

        tabbedPane.addTab("Calculator", calculatorPanel);
        tabbedPane.addTab("Converter", converterPanel);

        add(tabbedPane);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            MainFrame frame = new MainFrame();
            frame.setVisible(true);
        });
    }
}
