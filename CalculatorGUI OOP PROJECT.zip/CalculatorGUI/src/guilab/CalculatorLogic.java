package guilab;

public class CalculatorLogic {

    // Basic operations
    public double add(double a, double b) { return a + b; }
    public double subtract(double a, double b) { return a - b; }
    public double multiply(double a, double b) { return a * b; }
    public double divide(double a, double b) { 
        if (b == 0) throw new ArithmeticException("Divide by zero");
        return a / b; 
    }
    public double percent(double a) { return a / 100; }

    // Evaluate simple expressions (for scientific panel, basic version)
    public double evaluate(String expr) throws Exception {
        // For demo, only handle simple numbers or parse double directly
        // You can expand to full parser if needed
        expr = expr.replace("π", String.valueOf(Math.PI))
                   .replace("e", String.valueOf(Math.E))
                   .replace("×", "*")
                   .replace("÷", "/")
                   .replace("x", "*");

        return Double.parseDouble(expr);
    }

    // Scientific functions
    public double sin(double val) { return Math.sin(Math.toRadians(val)); }
    public double cos(double val) { return Math.cos(Math.toRadians(val)); }
    public double tan(double val) { return Math.tan(Math.toRadians(val)); }
    public double log(double val) { return Math.log10(val); }
    public double ln(double val) { return Math.log(val); }
    public double sqrt(double val) { return Math.sqrt(val); }
    public double power(double base, double exp) { return Math.pow(base, exp); }
    public double square(double value) { return value * value;}
    public long factorial(int n) {
        if (n < 0) throw new ArithmeticException("Factorial negative");
        long fact = 1;
        for (int i = 2; i <= n; i++) fact *= i;
        return fact;
    }

    // Converter methods
    public double convertLength(double val, String from, String to) {
        // base unit: meters
        double meters;

        switch (from) {
            case "Kilometer":
                meters = val * 1000;
                break;
            case "Meter":
                meters = val;
                break;
            case "Centimeter":
                meters = val / 100;
                break;
            case "Millimeter":
                meters = val / 1000;
                break;
            case "Mile":
                meters = val * 1609.34;
                break;
            case "Yard":
                meters = val * 0.9144;
                break;
            case "Foot":
                meters = val * 0.3048;
                break;
            case "Inch":
                meters = val * 0.0254;
                break;
            default:
                meters = val; // meters by default
                break;
        }

        switch (to) {
            case "Kilometer":
                return meters / 1000;
            case "Meter":
                return meters;
            case "Centimeter":
                return meters * 100;
            case "Millimeter":
                return meters * 1000;
            case "Mile":
                return meters / 1609.34;
            case "Yard":
                return meters / 0.9144;
            case "Foot":
                return meters / 0.3048;
            case "Inch":
                return meters / 0.0254;
            default:
                return meters;
        }
    }


        public double convertLength(String to, double meters) {
            switch (to) {
                case "Kilometer":
                    return meters / 1000;
                case "Meter":
                    return meters;
                case "Centimeter":
                    return meters * 100;
                case "Millimeter":
                    return meters * 1000;
                case "Mile":
                    return meters / 1609.34;
                case "Yard":
                    return meters / 0.9144;
                case "Foot":
                    return meters / 0.3048;
                case "Inch":
                    return meters / 0.0254;
                default:
                    return meters;
            }
        }


    public double convertMass(double val, String from, String to) {
        // base unit: kilogram
    	double kg;
    	switch (from) {
    	    case "Kilogram":
    	        kg = val;
    	        break;
    	    case "Gram":
    	        kg = val / 1000;
    	        break;
    	    case "Milligram":
    	        kg = val / 1_000_000;
    	        break;
    	    case "Pound":
    	        kg = val * 0.453592;
    	        break;
    	    case "Ounce":
    	        kg = val * 0.0283495;
    	        break;
    	    default:
    	        kg = val;
    	        break;
        };

        switch (to) {
        case "Kilogram":
            return kg;
        case "Gram":
            return kg * 1000;
        case "Milligram":
            return kg * 1_000_000;
        case "Pound":
            return kg / 0.453592;
        case "Ounce":
            return kg / 0.0283495;
        default:
            return kg;
        }
    }


    public double convertArea(double val, String from, String to) {
        double sqm;

        switch (from) {
            case "Square meter":
                sqm = val;
                break;
            case "Square kilometer":
                sqm = val * 1_000_000;
                break;
            case "Square mile":
                sqm = val * 2_589_988;
                break;
            case "Square yard":
                sqm = val * 0.836127;
                break;
            case "Square foot":
                sqm = val * 0.092903;
                break;
            case "Square inch":
                sqm = val * 0.00064516;
                break;
            case "Hectare":
                sqm = val * 10_000;
                break;
            case "Acre":
                sqm = val * 4046.86;
                break;
            default:
                sqm = val;
                break;
        }

        switch (to) {
            case "Square meter":
                return sqm;
            case "Square kilometer":
                return sqm / 1_000_000;
            case "Square mile":
                return sqm / 2_589_988;
            case "Square yard":
                return sqm / 0.836127;
            case "Square foot":
                return sqm / 0.092903;
            case "Square inch":
                return sqm / 0.00064516;
            case "Hectare":
                return sqm / 10_000;
            case "Acre":
                return sqm / 4046.86;
            default:
                return sqm;
        }
    }


    public double convertTime(double val, String from, String to) {
        double seconds;

        switch (from) {
            case "Second":
                seconds = val;
                break;
            case "Minute":
                seconds = val * 60;
                break;
            case "Hour":
                seconds = val * 3600;
                break;
            case "Day":
                seconds = val * 86400;
                break;
            case "Week":
                seconds = val * 604800;
                break;
            case "Month":
                seconds = val * 2_592_000; // 30 days approx
                break;
            case "Year":
                seconds = val * 31_536_000;
                break;
            default:
                seconds = val;
                break;
        }

        switch (to) {
            case "Second":
                return seconds;
            case "Minute":
                return seconds / 60;
            case "Hour":
                return seconds / 3600;
            case "Day":
                return seconds / 86400;
            case "Week":
                return seconds / 604800;
            case "Month":
                return seconds / 2_592_000;
            case "Year":
                return seconds / 31_536_000;
            default:
                return seconds;
        }
    }


    public double convertDiscount(double val, String from, String to) {
        // Discount is usually percentage based — example: apply discount or reverse
        // Let's just treat it as percent to decimal and vice versa
        if (from.equals("Percent") && to.equals("Decimal")) {
            return val / 100;
        } else if (from.equals("Decimal") && to.equals("Percent")) {
            return val * 100;
        }
        return val;
    }

    public double convertVolume(double val, String from, String to) {
        double liters;

        switch (from) {
            case "Liter":
                liters = val;
                break;
            case "Milliliter":
                liters = val / 1000;
                break;
            case "Cubic meter":
                liters = val * 1000;
                break;
            case "Cubic centimeter":
                liters = val / 1000;
                break;
            case "Gallon":
                liters = val * 3.78541;
                break;
            case "Pint":
                liters = val * 0.473176;
                break;
            default:
                liters = val;
                break;
        }

        switch (to) {
            case "Liter":
                return liters;
            case "Milliliter":
                return liters * 1000;
            case "Cubic meter":
                return liters / 1000;
            case "Cubic centimeter":
                return liters * 1000;
            case "Gallon":
                return liters / 3.78541;
            case "Pint":
                return liters / 0.473176;
            default:
                return liters;
        }
    }

    public double convertSpeed(double val, String from, String to) {
        double mps;

        switch (from) {
            case "m/s":
                mps = val;
                break;
            case "km/h":
                mps = val / 3.6;
                break;
            case "mph":
                mps = val * 0.44704;
                break;
            case "ft/s":
                mps = val * 0.3048;
                break;
            default:
                mps = val;
                break;
        }

        switch (to) {
            case "m/s":
                return mps;
            case "km/h":
                return mps * 3.6;
            case "mph":
                return mps / 0.44704;
            case "ft/s":
                return mps / 0.3048;
            default:
                return mps;
        }
    }


    public double convertTemperature(double val, String from, String to) {
        if (from.equals(to)) return val;

        if (from.equals("Celsius")) {
            if (to.equals("Fahrenheit")) {
                return val * 9 / 5 + 32;
            } else if (to.equals("Kelvin")) {
                return val + 273.15;
            } else {
                return val;
            }
        } else if (from.equals("Fahrenheit")) {
            if (to.equals("Celsius")) {
                return (val - 32) * 5 / 9;
            } else if (to.equals("Kelvin")) {
                return (val - 32) * 5 / 9 + 273.15;
            } else {
                return val;
            }
        } else if (from.equals("Kelvin")) {
            if (to.equals("Celsius")) {
                return val - 273.15;
            } else if (to.equals("Fahrenheit")) {
                return (val - 273.15) * 9 / 5 + 32;
            } else {
                return val;
            }
        }
        return val;
    }

    // Numeral system conversion (decimal to binary/octal/hex and vice versa)
    public String convertNumeralSystem(String val, String from, String to) throws NumberFormatException {
        int decimalValue;

        switch (from) {
            case "Binary":
                decimalValue = Integer.parseInt(val, 2);
                break;
            case "Octal":
                decimalValue = Integer.parseInt(val, 8);
                break;
            case "Decimal":
                decimalValue = Integer.parseInt(val);
                break;
            case "Hexadecimal":
                decimalValue = Integer.parseInt(val, 16);
                break;
            default:
                decimalValue = Integer.parseInt(val);
                break;
        }

        switch (to) {
            case "Binary":
                return Integer.toBinaryString(decimalValue);
            case "Octal":
                return Integer.toOctalString(decimalValue);
            case "Decimal":
                return String.valueOf(decimalValue);
            case "Hexadecimal":
                return Integer.toHexString(decimalValue).toUpperCase();
            default:
                return String.valueOf(decimalValue);
        }
    }
}

